#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <strings.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h> 
#include <sys/stat.h> 
#include <sys/statfs.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netdb.h>
#include <ifaddrs.h>

#include "curl/curl.h" 

#define CPU_TEMP_FILE "/sys/class/thermal/thermal_zone0/temp"
//#define CPU_TEMP_FILE "/sys/class/hwmon/hwmon0/temp2_input"
// #define IP_INTERFACE "wlan0"
#define IP_INTERFACE "eth0"
// #define IP_INTERFACE "enp0s25"
// #define IP_INTERFACE "wlp16s0"
#define ESP_IPADDR "192.168.1.125"
#define ESP_PORT   8080



/*
 * *************************************************************
 * Signal handling stuff
 * *************************************************************
*/

typedef void (*sighandler_t)(int);

static sighandler_t handle_signal (int sig_nr, sighandler_t signalhandler) 
{
   struct sigaction neu_sig, alt_sig;
   neu_sig.sa_handler = signalhandler;
   sigemptyset (&neu_sig.sa_mask);
   neu_sig.sa_flags = SA_RESTART;
   if (sigaction (sig_nr, &neu_sig, &alt_sig) < 0)
      return SIG_ERR;
   return alt_sig.sa_handler;
}

/*
 * *************************************************************
 * Make program to run as a daemon
 * *************************************************************
*/
static int runAsDaemon()
{
   int i;
   pid_t pid;
   int retVal = 0;

   if ((pid = fork ()) != 0)
   {
      if( pid < 0 )
      {
         retVal = 1;
      }
      else
      {
         // parent may exit now
         exit(0);
      }
   }

   if (setsid() < 0)
   {
      retVal = 2;
   }
   else
   {
      handle_signal (SIGHUP, SIG_IGN);

      chdir ("/");
      umask (0);

fprintf(stderr, "PID is %d\n", getpid() );

      for (i = sysconf (_SC_OPEN_MAX); i > 0; i--)
      {
         close (i);
      }
   }

   return( retVal );
}
/*
 * *************************************************************
 * read info about memory usage from /proc/mwminfo
 * *************************************************************
*/
void getMemInfo( unsigned long *pMemFree )
{
    FILE *fdMem;
    char avgBuffer[512];

    if( (fdMem = fopen("/proc/meminfo", "r")) != NULL )
    {
        while( fgets(avgBuffer, sizeof(avgBuffer), fdMem) != NULL )
        {
            // done if MemFree found
            if( sscanf( avgBuffer, "MemFree:         %lu kB", pMemFree ) )
            {
                break;
            }
        }
        fclose( fdMem );
    }
}
/*
 * *************************************************************
 * read info about CPU temperature from procfs
 * this depends on the platform you are using
 * for the Raspberry Pi set CPU_TEMP_FILE
 * to "/sys/class/thermal/thermal_zone0/temp"
 * ( see #defines on top of this file )
 * On other platforms you have to figure out which
 * file contains the desired info.
 * *************************************************************
*/
void getCpuTemp( unsigned long *pTemp )
{
    FILE *fdTemp;
    char tempBuffer[512];

    if( (fdTemp = fopen(CPU_TEMP_FILE, "r")) != NULL )
    {
        if( fgets(tempBuffer, sizeof(tempBuffer), fdTemp) != NULL )
        {
            sscanf( tempBuffer, "%lu", pTemp );
        }
        fclose( fdTemp );
    }
}
/*
 * *************************************************************
 * read info about load average from /proc/loadavg
 * Point of interest are the first three values.
 * They represent the load average of the last minute,
 * the last 5 minutes and the last 15 minutes.
 * I use the first value ...
 * You have to change the sscanf if you want to use another
 * value.
 * *************************************************************
*/
void getLoadAvg( float *pAvg )
{
    FILE *fdAvg;
    char avgBuffer[512];

    if( (fdAvg = fopen("/proc/loadavg", "r")) != NULL )
    {
        if( fgets(avgBuffer, sizeof(avgBuffer), fdAvg) != NULL )
        {
            sscanf( avgBuffer, "%f", pAvg );
        }
        fclose( fdAvg );
    }
}
/*
 * *************************************************************
 * read filesystem info of /root-filesystem using
 * statfs() systemcall
 * *************************************************************
*/
void getRootFSInfo( unsigned long *blocks )
{
    struct statfs fsb;

    if (statfs("/", &fsb) == -1) 
    {
        return;
    }

    // we need amount of MB
    *blocks = (unsigned long) (fsb.f_bavail * (fsb.f_bsize / 1024)) / 1024;

    return;
}
/*
 * *************************************************************
 * detect the local IP using getifaddrs()
 * set IP_INTERFACE to match the name of the network
 * adapter of interest.
 * ( see defines at top of this file )
 * Often used names are "eth0" for LAN and
 * "wlan0" for WLAN connections.
 * *************************************************************
*/
void getLocalIP(int *pAbyte, int *pBbyte, int *pCbyte, int *pDbyte )
{
    struct ifaddrs *ifaddr, *ifa;
    int s;
    char host[NI_MAXHOST];

    if (getifaddrs(&ifaddr) == -1) 
    {
        perror("getifaddrs");
        exit(EXIT_FAILURE);
    }


    for (ifa = ifaddr; ifa != NULL; ifa = ifa->ifa_next) 
    {
        if (ifa->ifa_addr == NULL)
            continue;  

        s=getnameinfo(ifa->ifa_addr,sizeof(struct sockaddr_in),host, NI_MAXHOST, NULL, 0, NI_NUMERICHOST);

        if((strcmp(ifa->ifa_name,IP_INTERFACE)==0)&&(ifa->ifa_addr->sa_family==AF_INET))
        {
            if (s != 0)
            {
                return;
            }

            sscanf(host, "%d.%d.%d.%d", pAbyte, pBbyte, pCbyte, pDbyte );

        }
    }

    freeifaddrs(ifaddr);
}
/* Never writes anything, just returns the size presented */
size_t curl_dummy_write(char *ptr, size_t size, size_t nmemb, void *userdata)
{
   return size * nmemb;
}
/*
 * *************************************************************
 * sendCurl() submits the URL given in curlBuffer[]
 * a html-page containing 
 * 0 OK resp.
 * -1 FAIL
 * is displayed by the ESP if all went ok resp. when
 * an error occurred.
 * Beware! This is a prototyp only with mostly no error-
 * checking at all.
 * *************************************************************
*/
void sendCurl(char curlBuffer[])
{
    static CURL *curl;
    static CURLcode res;

    if( (curl = curl_easy_init()) )
    {
//         sprintf(curlBuffer, 
        curl_easy_setopt(curl, CURLOPT_URL, curlBuffer);

        /* example.com is redirected, so we tell libcurl to follow redirection */
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_dummy_write);

        /* Perform the request, res will get the return code */
        res = curl_easy_perform(curl);
        /* Check for errors */
        if(res != CURLE_OK)
        {
// printf makes no sense in daemon mode!
//            fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));
        }
        /* always cleanup */
        curl_easy_cleanup(curl);
    }
}
/*
 * *************************************************************
 * main loop ... get the desired info and prepare a
 * buffer for the according cURL-call.
 * Because our ESP has no RTC the date/time update
 * ia called every second.
 * *************************************************************
*/
int main (void)
{
    time_t curtime;
    struct tm *loctime;
    char curlBuffer[512];
    unsigned long freeRootBlocks;
    unsigned long freeMem;
    unsigned long Temp;
    float loadAvg;
    int Abyte, Bbyte, Cbyte, Dbyte;
    char convBuffer[128];

    runAsDaemon();

    getLocalIP( &Abyte, &Bbyte, &Cbyte, &Dbyte );
    sprintf(curlBuffer, "http://%s:%d/ipdaddress?a=%d&b=%d&c=%d&d=%d", ESP_IPADDR, ESP_PORT, Abyte, Bbyte, Cbyte, Dbyte );
//fprintf(stderr, "%s\n", curlBuffer);
    sendCurl(curlBuffer);

    while( 1 )
    {
        /* Get the current time. */
        curtime = time (NULL);

        /* Convert it to local time representation. */
        loctime = localtime (&curtime);

        getRootFSInfo( &freeRootBlocks );

        getLoadAvg( &loadAvg );

        getMemInfo( &freeMem );

        sprintf(curlBuffer, "http://%s:%d/datetime?day=%d&month=%d&year=%d&hour=%d&minute=%d&second=%d&wday=%d",
            ESP_IPADDR, ESP_PORT, 
            loctime->tm_mday, loctime->tm_mon+1, loctime->tm_year+1900,
            loctime->tm_hour, loctime->tm_min, loctime->tm_sec, loctime->tm_wday );
//fprintf(stderr, "%s\n", curlBuffer);
        sendCurl(curlBuffer);


        getCpuTemp( &Temp );

        sprintf(convBuffer, "%1.2f", (float) (Temp / 1000.0) - (int)(Temp / 1000) );

        sprintf(curlBuffer, "http://%s:%d/cputemp?degree=%lu&tenth=%s", 
            ESP_IPADDR, ESP_PORT, 
            (Temp / 1000), (char*) convBuffer+2 );
//fprintf(stderr, "%s\n", curlBuffer);
        sendCurl(curlBuffer);

        sprintf(convBuffer, "%1.2f", (loadAvg - (int) loadAvg));
        sprintf(curlBuffer, "http://%s:%d/systemload?load=%d&tenth=%s", 
            ESP_IPADDR, ESP_PORT, 
            (int) loadAvg, (char*) convBuffer+2);
//fprintf(stderr, "%s\n", curlBuffer);
        sendCurl(curlBuffer);

        sprintf(curlBuffer, "http://%s:%d/freemem?freemem=%lu&freesd=%lu",
            ESP_IPADDR, ESP_PORT, 
           (freeMem / 1024), freeRootBlocks );
//fprintf(stderr, "%s\n", curlBuffer);
        sendCurl(curlBuffer);

        sleep(1);
    }

    return 0;
}


